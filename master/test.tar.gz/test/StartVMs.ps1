Set-Location /home/ansible/pprd
ansible-playbook /home/ansible/pprd/100_StartVMs.yaml


Set-Location /home/ansible
